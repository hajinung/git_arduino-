^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package open_manipulator_p
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2020-10-15)
-------------------
* First release of the open_manipulator_p stack
* Contributors: Ryan Shim, YongHo-Na, HyeJong KIM
